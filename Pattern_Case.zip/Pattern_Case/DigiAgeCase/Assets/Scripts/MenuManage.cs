﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MenuManage : MonoBehaviour
{
    private Button PlayButton;
    private Button QuitButton;

    private void Awake()
    {
        PlayButton = GameObject.Find("PlayButton").GetComponent<Button>();
        QuitButton = GameObject.Find("QuitButton").GetComponent<Button>();
    }

    private void Start()
    {
        PlayButton.onClick.AddListener(PlayGame);
        QuitButton.onClick.AddListener(QuitTheGame);
    }

    private void PlayGame()
    {
        SceneManager.LoadScene(1);
    }

    private void QuitTheGame()
    {
        Application.Quit();
        Debug.Log("çıkıldı");
    }
}
