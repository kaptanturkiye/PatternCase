﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameFinal : MonoBehaviour
{
    #region Değişken Tanımları

    private GameObject endTheGame;
    private bool isGameFinish = false;

    private GameObject player;
    private int deger;
    private int degerr;

    private GameObject FinalPanel;
    private GameObject FinalPanel2;
    private Text point;
    private Text point2;
    private Button BackButton;
    private Button BackButton2;
    private Button NextLevel;
    private Button RepeatLevel;
    
    #endregion
    
    private void Awake()
    {
        
        player = GameObject.FindObjectOfType<PlayerManager>().gameObject;
        
        endTheGame = GameObject.Find("Road");
        FinalPanel = GameObject.Find("FinalPanel");
        FinalPanel2 = GameObject.Find("FinalPanel2");
        
        point = GameObject.Find("Puan").GetComponent<Text>();
        point2 = GameObject.Find("Puan2").GetComponent<Text>();
        
        NextLevel = GameObject.Find("NextLevel").GetComponent<Button>();
        RepeatLevel = GameObject.Find("RepeatLevel").GetComponent<Button>();
        BackButton = GameObject.Find("BackButton").GetComponent<Button>();
        BackButton2 = GameObject.Find("BackButton2").GetComponent<Button>();
    }

    private void Start()
    {
        FinalPanel.SetActive(false);
        FinalPanel2.SetActive(false);
        BackButton.onClick.AddListener(BackMenu);
        BackButton2.onClick.AddListener(BackMenu);
        NextLevel.onClick.AddListener(openNextLevel);
        RepeatLevel.onClick.AddListener(openThisLevel);
    }

    private void Update()
    {
        if (isGameFinish == false && endTheGame.transform.position.z < -30)
        {
            Debug.Log("OYUN Kazanıldı");
            isGameFinish = true;
            FinalPanel.SetActive(true);
            deger = player.GetComponent<PlayerManager>().numberOfStickmans;
            Debug.Log(deger);
            point.text = deger.ToString();
        }
        
        if (isGameFinish == false && player.GetComponent<PlayerManager>().numberOfStickmans <= 0)
        {
            Debug.Log("OYUN Kaybedildi");
            isGameFinish = true;
            FinalPanel2.SetActive(true);
            deger = player.GetComponent<PlayerManager>().numberOfStickmans;
            Debug.Log(deger);
            point2.text = deger.ToString();
        }
    }

    #region Sahneler Arası Geçiş
    
    private void BackMenu()
    {
        SceneManager.LoadScene(0);
    }

    private void openNextLevel()
    {
        SceneManager.LoadScene(2);
    }
    
    private void openThisLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
      
    }
    
    #endregion
}
